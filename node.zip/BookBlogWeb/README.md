# BookBlogWeb
Its a website wear one will be publishing an a description abou a book has read and the rating
